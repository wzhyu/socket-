//
//  ViewController.m
//  socket客户端
//
//  Created by 杭州共联房地产 on 17/2/20.
//  Copyright © 2017年 杭州共联房地产. All rights reserved.
//

#import "ViewController.h"
#import "GCDAsyncSocket.h"


@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,GCDAsyncSocketDelegate>



@property(nonatomic,strong)UITableView  *table;
@property(nonatomic,strong)GCDAsyncSocket *scoket;
@property(nonatomic,strong)GCDAsyncSocket *ServerSocket;
@property(nonatomic,strong)NSMutableArray  *array;


@end


@implementation ViewController

-(NSMutableArray *)array{
    if (!_array){
        _array=[[NSMutableArray alloc]init];
        
    }
    return _array;
}


-(GCDAsyncSocket *)scoket{
    if (!_scoket){
        _scoket= [[GCDAsyncSocket alloc]initWithDelegate:self delegateQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
        

    }
    return _scoket;
}



-(UITableView *)table{
    if (!_table){
       
        _table=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, 480) style:UITableViewStylePlain];
        _table.delegate = self;
        _table.dataSource = self;
        [_table registerClass:[UITableViewCell class] forCellReuseIdentifier:@"123"];
        
    }
    return _table;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.table];
    
    [self.scoket connectToHost:@"127.0.0.1" onPort:1280 error:nil];//连接服务器,这个是连接断开和ip的,还有用url连接的这个是本机测试的
    
    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(readData) userInfo:nil repeats:YES];
    
}



-(void)readData{
    
    [self.ServerSocket readDataWithTimeout:-1 tag:0];


}

-(void)socket:(GCDAsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag{

    
    
    NSString *str = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    
    NSLog(@"%@",str);
    [self.array addObject:str];
    
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
          [self.table reloadData];//但是注意,前面那个socket是在分线程里创建的,刷新ui要在主线程,所以在数据刷新会出现不出现
        if (self.array.count>2) {
            [self.table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.array.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
            
            
        }

    });
    
    
    
}

//当客户端连接成功的时候进入此代理方法
-(void)socket:(GCDAsyncSocket *)sock didConnectToHost:(NSString *)host port:(uint16_t)port{

    self.ServerSocket = sock;
    NSLog(@"成功连接到服务器");
    NSString *str =@"didConcennetToHost";
    [sock writeData:[str dataUsingEncoding:NSUTF8StringEncoding] withTimeout:-1 tag:0];
    
    
 
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.array.count;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"123" forIndexPath:indexPath];
    cell.textLabel.text = self.array[indexPath.row];
    
    
    return cell;
}


@end
