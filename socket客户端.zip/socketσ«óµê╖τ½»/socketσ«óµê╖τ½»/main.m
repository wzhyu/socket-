//
//  main.m
//  socket客户端
//
//  Created by 杭州共联房地产 on 17/2/20.
//  Copyright © 2017年 杭州共联房地产. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
