//
//  ViewController.m
//  sockrt服务器端
//
//  Created by 杭州共联房地产 on 17/2/18.
//  Copyright © 2017年 杭州共联房地产. All rights reserved.
//

#import "ViewController.h"
#import "GCDAsyncSocket.h"


@interface ViewController ()<GCDAsyncSocketDelegate>

@property(nonatomic,strong)GCDAsyncSocket *serverSocket;
@property(nonatomic,strong)GCDAsyncSocket *clientSocket;
@property(nonatomic,strong)NSMutableArray *arrayClient;

@end

@implementation ViewController

-(NSMutableArray *)arrayClient{

    if (_arrayClient ==nil) {
        _arrayClient = [[NSMutableArray alloc]init];
    }

    return _arrayClient;
}

-(GCDAsyncSocket *)serverSocket{
    if (_serverSocket ==nil) {
        _serverSocket = [[GCDAsyncSocket alloc]initWithDelegate:self delegateQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
        
    }
    return _serverSocket;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /*1.引入第三方,GCDAsyncSocket
     2. 创建socket 对象 (一般选用懒加载,节省内存)
     3.绑定端口
     特别注意:在绑定端口的时候,我们肯定要知道端口号,window获取本机端口使用ipcongif,MacOS用ifcongif在终端 它们显示的四个数字大于1024的你可以试试, flags这个后面的应该就是你查询的主机端口号,ip本机是用127.0.0.1 别人连接就去查找自己的局域ip换成那个即可 终端指令为 ifconfig | grep "inet " | grep -v 127.0.0.1
     
     
     记住同一个局域网,的同一个子码 192.168.1(字码).11,才能平的痛
     4.监听端口
     5.接受客户端的连接
     6.读写
     
     */

    NSError *error=nil;
    [self.serverSocket acceptOnPort:1280 error:&error];//绑定端口
    NSLog(@"%@",error);

    //这个是每秒读取一次
    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(readData) userInfo:nil repeats:YES];
}


//读取数据
-(void)readData{
    
    if (self.arrayClient.count==0) {
       
        return;
        
    }
  
    for (GCDAsyncSocket *socket in self.arrayClient) {
        [socket readDataWithTimeout:-1 tag:0];//读取每一个
        
    }

}

//监听端口
-(void)socket:(GCDAsyncSocket *)sock didAcceptNewSocket:(GCDAsyncSocket *)newSocket{

//newSocket 就是链接过来的新客户端
    
    
    NSLog(@"ip:%@---port:%d",newSocket.connectedHost,newSocket.connectedPort);
    
    
    self.clientSocket = newSocket;//这个是为了进来的客户端一直都存在,不会释放,但是多个的时候就要存到数组了
    [self.arrayClient addObject:newSocket];
    
    
   
    NSString * str = @"欢迎连接服务器";
    //下面这个是连接上来后就返回这个服务端发送到客户端 -1表示永久 tag 无所谓
    [newSocket writeData:[str dataUsingEncoding:NSUTF8StringEncoding] withTimeout:-1 tag:0];
    
  //  [newSocket readDataWithTimeout:-1 tag:0];//这个读取客户端发来的数据,但是这样他只能读取一次,为了多次读取,用定时器,
    
    
}

-(void)socket:(GCDAsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag{

    NSString *str= [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    
    //读出来的同时有写进去
   for (GCDAsyncSocket *socket in self.arrayClient) {
//       if (socket !=self.clientSocket) {
//          
//           continue;
//      }
//       
        [socket writeData:[str dataUsingEncoding:NSUTF8StringEncoding] withTimeout:-1 tag:0];
}
    
    NSLog(@"%@",str);
    
    
    
}

@end
